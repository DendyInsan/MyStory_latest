package com.dicoding.mystory.model

data class UserModel(
                      val token: String,
                      val name: String,
                      val isLogin: Boolean)
